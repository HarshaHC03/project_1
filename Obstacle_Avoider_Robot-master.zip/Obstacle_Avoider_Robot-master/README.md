# Obstacle Avoider Robot
The "Obstacle Avoider Robot" uses IR Proximity Sensor to detect obstacles, the data is then processed by ATmega16 and ultimately, the robot avoids the obstacle successfully.
